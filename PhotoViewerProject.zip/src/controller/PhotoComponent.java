package controller;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.List;
import interfaces.IPhotoModel;
import model.PhotoModel;
import model.Stroke;
import model.Annotation;
import view.PhotoView;
import utils.Constants;

public class PhotoComponent extends PACController {
    private final IPhotoModel model;  
    private final PhotoView view;    
    private Stroke currentStroke;  
    private boolean isDrawing;     
    private boolean mousePressed;  
    private boolean mouseMoved;
    
    private final AnnotationHitTester annotationHitTester = new AnnotationHitTester();

    public PhotoComponent(String imagePath) {
        this.model = new PhotoModel();
        this.view = new PhotoView(); 
        setupEventHandlers();
        setupViewEventListeners();
    }
    
    private void setupViewEventListeners() {
        view.setImportActionListener(e -> importImage());
        view.setDeleteActionListener(e -> deletePhoto());
        view.setColorActionListener(e -> showColorChooser());
        view.setStatusUpdateListener(message -> updateStatusBar(message));
    }
    
    private void showColorChooser() {
        Color selectedColor = JColorChooser.showDialog(this, "Choose Annotation Color", Color.BLACK);
        if (selectedColor != null) {
            setAnnotationColor(selectedColor);
        }
    }
    
    private void updateStatusBar(String message) {

        JComponent parent = (JComponent) getParent();
        while (parent != null) {
            JLabel statusLabel = findStatusLabel(parent);
            if (statusLabel != null) {
                statusLabel.setText(message);
                break;
            }
            parent = (JComponent) parent.getParent();
        }
    }
    
    private JLabel findStatusLabel(Container container) {
        for (Component comp : container.getComponents()) {
            if (comp instanceof JLabel && "statusLabel".equals(comp.getName())) {
                return (JLabel) comp;
            } else if (comp instanceof Container) {
                JLabel found = findStatusLabel((Container) comp);
                if (found != null) {
                    return found;
                }
            }
        }
        return null;
    }

    public void toggleFlip() {
        model.toggleFlipped();
        refreshView();
    }

    public void toggleAnnotationsVisible() {
        model.toggleAnnotationsVisible();
        refreshView();
    }
    
    public void setAnnotationColor(Color color) {
        Object selectedObject = model.getSelectedObject();
        if (selectedObject != null) {
            if (selectedObject instanceof Annotation) {
                ((Annotation) selectedObject).setColor(color);
            }
           
            refreshView();
        }
    }

 
    private Object findObjectAt(int x, int y, int photoWidth) {
      
        for (Annotation annotation : model.getAnnotations()) {
          
            if (annotation == model.getCurrentTextAnnotation() && annotation.isEmpty()) {
                continue;
            }
            if (annotationHitTester.containsPoint(annotation, x, y, photoWidth)) {
                return annotation;
            }
        }
        
        return null;
    }

    private Point getObjectPosition(Object obj) {
        if (obj instanceof Stroke) {
            return ((Stroke) obj).getCenter();
        } else if (obj instanceof Annotation) {
            return ((Annotation) obj).getPosition();
        }
        return new Point(0, 0);
    }

    private void moveObject(Object obj, int dx, int dy) {
        if (obj instanceof Stroke) {
            ((Stroke) obj).moveBy(dx, dy);
        } else if (obj instanceof Annotation) {
            ((Annotation) obj).moveBy(dx, dy);
        }
        refreshView();
    }

    public void loadImage(File imageFile) {
        model.loadImage(imageFile);
        refreshView();
    }

    private void startDrawing(int x, int y) {
        if (isWithinPhotoBounds(x, y)) {
            currentStroke = new Stroke(Constants.STROKE_COLOR, Constants.STROKE_WIDTH);
            currentStroke.addPoint(x, y);
            isDrawing = true;
        }
    }

    private void continueDrawing(int x, int y) {
        if (isDrawing && currentStroke != null && isWithinPhotoBounds(x, y)) {
            currentStroke.addPoint(x, y);
            repaint(); 
        }
    }

    private void finishDrawing() {
        if (isDrawing && currentStroke != null && !currentStroke.isEmpty()) {
            model.addStroke(currentStroke);
            refreshView();
        }
        currentStroke = null;
        isDrawing = false;
    }

    private boolean isWithinPhotoBounds(int x, int y) {
        if (!model.hasImage()) {
            Dimension componentSize = getSize();
            return x >= 0 && x < componentSize.width && y >= 0 && y < componentSize.height;
        }
        Dimension photoSize = model.getImageDimensions();
        return x >= 0 && x < photoSize.width && y >= 0 && y < photoSize.height;
    }

    private void setTextInsertionPoint(int x, int y) {
        if (isWithinPhotoBounds(x, y)) {
            model.setTextInsertionPoint(new Point(x, y));
            requestFocusInWindow(); 
            repaint();
        }
    }

    @Override
    protected void refreshView() {
        revalidate();
        repaint();
    }

    private void setupEventHandlers() {
        setupMouseHandlers();
        setupKeyboardHandlers();
        setFocusable(true);
    }
    
    private void setupMouseHandlers() {
        addMouseListener(createMouseListener());
        addMouseMotionListener(createMouseMotionListener());
    }
    
    private MouseAdapter createMouseListener() {
        return new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                handleMousePressed(e);
            }
            public void mouseReleased(MouseEvent e) {
                handleMouseReleased(e);
            }
            public void mouseClicked(MouseEvent e) {
                handleMouseClicked(e);
            }
        };
    }
    
    private MouseMotionAdapter createMouseMotionListener() {
        return new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                handleMouseDragged(e);
            }
        };
    }
    
    private void handleMousePressed(MouseEvent e) {
        if (!model.isAnnotationsVisible() || e.getButton() != MouseEvent.BUTTON1) {
            return;
        }
        
        mousePressed = true;
        mouseMoved = false;
        requestFocusInWindow();
        
        int x = e.getX();
        int y = e.getY();
        

        BufferedImage image = model.getImage();
        int photoWidth = (image != null) ? image.getWidth() : 0;
        
  
        Object clickedObject = findObjectAt(x, y, photoWidth);
        model.setSelectedObject(clickedObject);
        
        if (clickedObject != null) {
         
            Point objectPos = getObjectPosition(clickedObject);
            model.setDragOffset(new Point(x - objectPos.x, y - objectPos.y));
        } else if (isWithinPhotoBounds(x, y)) {
       
        }
        
        refreshView();
    }
    
    private void handleMouseReleased(MouseEvent e) {
        if (!mousePressed || !model.isAnnotationsVisible() || e.getButton() != MouseEvent.BUTTON1) {
            return;
        }
        
        int x = e.getX();
        int y = e.getY();
        
        if (mouseMoved && isDrawing) {
          
            finishDrawing();
        } else if (!mouseMoved && model.getSelectedObject() == null && isWithinPhotoBounds(x, y)) {
         
            setTextInsertionPoint(x, y);
        } else if (mouseMoved && model.getSelectedObject() != null) {
         
            model.setDragging(false);
        }
        
        mousePressed = false;
        mouseMoved = false;
        refreshView();
    }
    
    private void handleMouseClicked(MouseEvent e) {
        if (e.getClickCount() == 2) {
            toggleAnnotationsVisible();
        }
    }
    
    private void handleMouseDragged(MouseEvent e) {
        if (!mousePressed || !model.isAnnotationsVisible()) {
            return;
        }
        
        mouseMoved = true;
        int x = e.getX();
        int y = e.getY();
        
        if (isDrawing) {
          
            continueDrawing(x, y);
        } else if (model.getSelectedObject() != null) {
          
            if (!model.isDragging()) {
                model.setDragging(true);
            }
          
            Point dragOffset = model.getDragOffset();
            int dx = x - dragOffset.x - getObjectPosition(model.getSelectedObject()).x;
            int dy = y - dragOffset.y - getObjectPosition(model.getSelectedObject()).y;
            
            moveObject(model.getSelectedObject(), dx, dy);
        } else if (isWithinPhotoBounds(x, y)) {
          
            if (!isDrawing) {
                startDrawing(x, y);
            }
        }
    }
    
    private void setupKeyboardHandlers() {
        addKeyListener(createKeyListener());
    }
    
    private KeyAdapter createKeyListener() {
        return new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                handleKeyPressed(e);
            }
        };
    }
    
    private void handleKeyPressed(KeyEvent e) {
        if (!model.isAnnotationsVisible()) {
            return;
        }
        
       
        if (model.getCurrentTextAnnotation() != null) {
            handleTextInput(e);
        }
      
        else if (model.getSelectedObject() instanceof Annotation) {
            Annotation annotation = (Annotation) model.getSelectedObject();
            model.setCurrentTextAnnotation(annotation);
            handleAnnotationTextInput(e, annotation);
        }
    }
    
    private void handleTextInput(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_BACK_SPACE) {
            model.backspaceCurrentText();
            repaint();
        } else if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            model.commitCurrentText();
            repaint();
        } else if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
            model.setTextInsertionPoint(null);
            repaint();
        } else if (e.getKeyChar() >= 32 && e.getKeyChar() <= 126) {
            model.addToCurrentText(e.getKeyChar());
            repaint();
        }
    }

    private void handleAnnotationTextInput(KeyEvent e, Annotation annotation) {
      
        if (!annotation.isEditing()) {
            annotation.setEditing(true);
        }
        
        if (e.getKeyCode() == KeyEvent.VK_BACK_SPACE) {
            annotation.backspace();
            repaint();
        } else if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            annotation.setEditing(false);
            repaint();
        } else if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
            annotation.setEditing(false);
            model.setSelectedObject(null);
            repaint();
        } else if (e.getKeyChar() >= 32 && e.getKeyChar() <= 126) {
            annotation.addCharacter(e.getKeyChar());
            repaint();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
     
        boolean isFlipped = model.isFlipped();
        boolean annotationsVisible = model.isAnnotationsVisible();
        BufferedImage image = model.getImage();
        List<Stroke> strokes = model.getStrokes();
        List<Annotation> annotations = model.getAnnotations();
        Annotation currentTextAnnotation = model.getCurrentTextAnnotation();
        Object selectedObject = model.getSelectedObject();
        view.draw(g, this, isFlipped, annotationsVisible, image, strokes, annotations, currentTextAnnotation, selectedObject);
    }

    @Override
    public Dimension getPreferredSize() {
     
        BufferedImage image = model.getImage();
        return view.getPreferredSize(image);
    }

    public JMenuBar createMenuBar() {
        return view.createMenuBar();
    }

    public void importImage() {
   
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Select Image File");
        File imgDir = new File("img");
        if (imgDir.exists()) {
            fileChooser.setCurrentDirectory(imgDir);
        }
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            loadImage(selectedFile);
        }
    }

    public JPanel createToolBar() {
        return view.createToolBar();
    }

    public void deletePhoto() {

        model.clearAll();

        resetControllerState();

        refreshView();
    }
    
    private void resetControllerState() {
        currentStroke = null;
        isDrawing = false;
        mousePressed = false;
        mouseMoved = false;
    }

    public JPanel createStatusBar(){
        return view.createStatusBar();
    }
}
